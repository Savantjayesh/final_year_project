export class Appointment {

    id: number;
    name: string;
    age: string;
    symptoms: string;
    number: string;
}
