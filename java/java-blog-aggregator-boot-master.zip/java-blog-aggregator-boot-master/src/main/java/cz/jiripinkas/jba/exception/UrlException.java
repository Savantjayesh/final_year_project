package cz.jiripinkas.jba.exception;

public class UrlException extends Exception {

	private static final long serialVersionUID = 1L;

	public UrlException(String message) {
		super(message);
	}
}
