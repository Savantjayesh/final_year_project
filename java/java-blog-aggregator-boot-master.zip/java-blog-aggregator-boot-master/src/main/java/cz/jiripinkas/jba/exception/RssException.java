package cz.jiripinkas.jba.exception;

public class RssException extends Exception {

	private static final long serialVersionUID = 1L;

	public RssException(Throwable cause) {
		super(cause);
	}

	public RssException(String message) {
		super(message);
	}

}
