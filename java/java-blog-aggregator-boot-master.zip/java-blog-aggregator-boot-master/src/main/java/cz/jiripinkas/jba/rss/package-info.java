@XmlSchema(namespace = "", elementFormDefault = XmlNsForm.QUALIFIED, xmlns = { @XmlNs(prefix = "feedburner", namespaceURI = "http://rssnamespace.org/feedburner/ext/1.0"),
		@XmlNs(prefix = "content", namespaceURI = "http://purl.org/rss/1.0/modules/content/") })
package cz.jiripinkas.jba.rss;

import javax.xml.bind.annotation.XmlNs;
import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;

