package cz.jiripinkas.jba.entity;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "news_item")
public class NewsItem {

	@Id
	@GeneratedValue
	private Integer id;

	@Column(length = 500)
	private String title;

	@Column(name = "short_description", length = 500)
	private String shortDescription;

	@Column(length = Integer.MAX_VALUE)
	@Lob
	private String description;

	@Column(name = "published_date")
	private Date publishedDate;

	@Column(name = "short_name", length = 500, unique = true)
	private String shortName;
	
	public String getFormattedPuslihedDate() {
		return new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(publishedDate);
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getPublishedDate() {
		return publishedDate;
	}

	public void setPublishedDate(Date publishedDate) {
		this.publishedDate = publishedDate;
	}

}
