@XmlSchema(namespace = "http://www.w3.org/2005/Atom", elementFormDefault = XmlNsForm.QUALIFIED, xmlns = { @XmlNs(prefix = "feedburner", namespaceURI = "http://rssnamespace.org/feedburner/ext/1.0") })
package cz.jiripinkas.jba.atom;

import javax.xml.bind.annotation.XmlNs;
import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;

