from django.apps import AppConfig


class DregConfig(AppConfig):
    name = 'dreg'
