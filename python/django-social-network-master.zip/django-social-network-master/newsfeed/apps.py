from django.apps import AppConfig


class NewsfeedConfig(AppConfig):
    name = 'newsfeed'
