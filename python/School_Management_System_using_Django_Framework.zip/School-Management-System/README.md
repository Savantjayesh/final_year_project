# School-Management-System
This is a School Management System software developed by Django and sqlite3. In this software you can manage Students Registration, Students info, Teachers Registration, etc. I will also add a system in this software very soon so you can manage students results also.

This is a School Management System software developed by Django and sqlite3. In this software you can manage Students Registration, Students info, Teachers Registration, etc. I will also add a system in this software very soon so you can manage students results also.

### 1. Added Student Result System to manage and maintain their performances

### 2. Added Students Attendance Count System

### 3. Will add complete Employee Management System for Teachers and others Stuff
